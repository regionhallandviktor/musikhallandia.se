<?php

	/**
	 * @package Region Halland Blog Info
	 */
	/*
	Plugin Name: Region Halland Blog Info
	Description: Front-end-plugin som returnerar info om webbplatsen
	Version: 1.0.0
	Author: Roland Hydén
	License: Free to use
	Text Domain: region_halland_blog_info
	*/

	// Returnera namn på webbplatsen
	function get_region_halland_blog_name() {
		return get_bloginfo('name');
	}

	// Returnera beskrivning av webbplatsen
	function get_region_halland_blog_description() {
		return get_bloginfo('description');
	}

	// Returnera url till webbplatsen
	function get_region_halland_blog_url() {
		return get_bloginfo('url');
	}

	// Metod som anropas när pluginen aktiveras
	function region_halland_blog_info_activate() {
		// Nothing at the moment
	}

	// Metod som anropas när pluginen avaktiveras
	function region_halland_blog_info_deactivate() {
		// Nothing at the moment
	}
	
	// Vilken metod som ska anropas när pluginen aktiveras
	register_activation_hook( __FILE__, 'region_halland_blog_info_activate');

	// Vilken metod som ska anropas när pluginen avaktiveras
	register_deactivation_hook( __FILE__, 'region_halland_blog_info_deactivate');